webdriver_path = r'C:\Users\dlee9\Downloads\chromedriver_win32\chromedriver.exe'

url_ozon = "https://www.ozon.ru/category/noutbuki-15692/" # проблемы с cloudflare

# url_mvideo = "https://www.mvideo.ru/noutbuki-planshety-komputery-8/noutbuki-118" # good
url_mvideo = "https://www.mvideo.ru/noutbuki-planshety-komputery-8/noutbuki-118?page={}" # good

headers = [
    'PriceNow',
    'PriceOriginal',
    'Guarantee',
    'Country',
    'Series',
    'OS',
    'windows',
    'CoresNumber',
    'ProcessorModel',
    'Processor',
    'ProcessorType',
    'ProcessorFrequency',
    'GpuManufacturer',
    'GpuController',
    'GpuCapacity',
    'ScreenSize',
    'Diagonal',
    'ScreenFrequency',
    'SsdSize',
    'RAM',
    'RAM_type',
    'HDMI',
    'Material',
    'Battery',
    'Weight'
]

